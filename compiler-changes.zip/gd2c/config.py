def can_build(env, platform):
    return True

def configure(env):
    pass