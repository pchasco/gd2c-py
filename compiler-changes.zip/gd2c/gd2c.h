#ifndef GD2C_RUNTIME_SERVICES_H
#define GD2C_RUNTIME_SERVICES_H

#include "core/ustring.h"
#include "modules/gdnative/include/gdnative/gdnative.h"

#define GD2C_API_TYPE 9999
#define GD2C_API_VERSION_1 1

#ifdef __cplusplus
extern "C" {
#endif

void GDAPI gd2c_variant_get_named(
		const godot_variant *p_self,
		const godot_string *p_name,
		godot_variant *p_dest,
		godot_bool *r_error);

void GDAPI gd2c_variant_set_named(
		godot_variant *p_self,
		const godot_string *p_name,
		const godot_variant *p_value,
		godot_bool *r_error);

void GDAPI gd2c_object_get_property(
		const godot_object *p_instance,
		const godot_string *p_name,
		godot_variant *p_dest);

void GDAPI gd2c_object_set_property(
		godot_object *p_instance,
		const godot_string *p_name,
		const godot_variant *p_value,
		godot_bool *r_error);

void GDAPI gd2c_variant_set(
		godot_variant *p_instance,
		const godot_variant *p_index,
		const godot_variant *p_value,
		godot_bool *r_error);

void GDAPI gd2c_variant_get(
		const godot_variant *p_instance,
		const godot_variant *p_index,
		godot_variant *p_dest,
		godot_bool *r_error);

godot_error GDAPI gd2c_variant_decode(
		godot_variant *r_variant,
		const uint8_t *p_buffer,
		int p_len,
		int *r_len,
		godot_bool p_allow_objects);

void GDAPI gd2c_resource_load(
		godot_variant *r_result,
		const godot_string *p_path);

struct gd2c_api_1_struct {
	unsigned int api_id;
	unsigned int api_version;

	void (*variant_get_named)(const godot_variant *p_self, const godot_string *p_name, godot_variant *p_dest, godot_bool *r_error);
	void (*variant_set_named)(godot_variant *p_self, const godot_string *p_name, const godot_variant *p_value, godot_bool *r_error);
	void (*object_get_property)(const godot_object *p_instance, const godot_string *p_name, godot_variant *p_dest);
	void (*object_set_property)(godot_object *p_instance, const godot_string *p_name, const godot_variant *p_value, godot_bool *r_error);
	void (*variant_set)(godot_variant *p_instance, const godot_variant *p_index, const godot_variant *p_value, godot_bool *r_error);
	void (*variant_get)(const godot_variant *p_instance, const godot_variant *p_index, godot_variant *p_dest, godot_bool *r_error);
	godot_error (*variant_decode)(godot_variant *r_variant, const uint8_t *p_buffer, int p_len, int *r_len, godot_bool p_allow_objects);
	void (*resource_load)(godot_variant *r_result, const godot_string *p_path);
};

#ifdef __cplusplus
}
#endif

#endif