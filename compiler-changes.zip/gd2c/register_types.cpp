#include "register_types.h"

#include "core/class_db.h"
#include "bytecode_exporter.h"

void register_gd2c_types() {
    ClassDB::register_class<GDScriptBytecodeExporter>();
}

void unregister_gd2c_types() {
   //nothing to do here
}