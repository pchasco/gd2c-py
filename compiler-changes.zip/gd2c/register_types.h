void register_gd2c_types();
void unregister_gd2c_types();